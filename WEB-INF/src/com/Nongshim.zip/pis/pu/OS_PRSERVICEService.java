/**
 * OS_PRSERVICEService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.Nongshim.pis.pu;

public interface OS_PRSERVICEService extends javax.xml.rpc.Service {
    public java.lang.String getOS_PRSERVICEPortAddress();

    public com.Nongshim.pis.pu.OS_PRSERVICE getOS_PRSERVICEPort() throws javax.xml.rpc.ServiceException;

    public com.Nongshim.pis.pu.OS_PRSERVICE getOS_PRSERVICEPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
