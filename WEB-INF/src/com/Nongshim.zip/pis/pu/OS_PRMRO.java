/**
 * OS_PRMRO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.Nongshim.pis.pu;

public interface OS_PRMRO extends java.rmi.Remote {
    public com.Nongshim.pis.pu.DT_PRMRO_response OS_PRMRO(com.Nongshim.pis.pu.DT_PRMRO MT_PRMRO) throws java.rmi.RemoteException;
}
