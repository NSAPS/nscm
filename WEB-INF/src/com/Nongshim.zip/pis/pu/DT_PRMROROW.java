/**
 * DT_PRMROROW.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.Nongshim.pis.pu;

public class DT_PRMROROW  implements java.io.Serializable {
    private java.lang.String PRCH_REQT_SEQ;

    private java.lang.String ACCT_FIXD;

    private java.lang.String PRCH_DOCU_ATCL;

    private java.lang.String REQT_SITE_CODE;

    private java.lang.String REQT_DATE;

    private java.lang.String MATR_CODE;

    private java.lang.String PRCH_DOCU_DETL;

    private java.lang.String QTY_UNIT;

    private java.lang.String REQT_QTY;

    private java.lang.String CURRENCY;

    private java.lang.String PLAN_AMT;

    private java.lang.String CUST_CODE;

    private java.lang.String GL_ACCT;

    private java.lang.String USED_COST_CNTR;

    private java.lang.String WBS_NO;

    private java.lang.String PRCH_GRUP;

    private java.lang.String MATR_GRUP;

    private java.lang.String DELV_REQT_DATE;

    private java.lang.String REQT_RESN;

    private java.lang.String REQT_NAME;

    private java.lang.String REAL_NAME;

    public DT_PRMROROW() {
    }

    public DT_PRMROROW(
           java.lang.String PRCH_REQT_SEQ,
           java.lang.String ACCT_FIXD,
           java.lang.String PRCH_DOCU_ATCL,
           java.lang.String REQT_SITE_CODE,
           java.lang.String REQT_DATE,
           java.lang.String MATR_CODE,
           java.lang.String PRCH_DOCU_DETL,
           java.lang.String QTY_UNIT,
           java.lang.String REQT_QTY,
           java.lang.String CURRENCY,
           java.lang.String PLAN_AMT,
           java.lang.String CUST_CODE,
           java.lang.String GL_ACCT,
           java.lang.String USED_COST_CNTR,
           java.lang.String WBS_NO,
           java.lang.String PRCH_GRUP,
           java.lang.String MATR_GRUP,
           java.lang.String DELV_REQT_DATE,
           java.lang.String REQT_RESN,
           java.lang.String REQT_NAME,
           java.lang.String REAL_NAME) {
           this.PRCH_REQT_SEQ = PRCH_REQT_SEQ;
           this.ACCT_FIXD = ACCT_FIXD;
           this.PRCH_DOCU_ATCL = PRCH_DOCU_ATCL;
           this.REQT_SITE_CODE = REQT_SITE_CODE;
           this.REQT_DATE = REQT_DATE;
           this.MATR_CODE = MATR_CODE;
           this.PRCH_DOCU_DETL = PRCH_DOCU_DETL;
           this.QTY_UNIT = QTY_UNIT;
           this.REQT_QTY = REQT_QTY;
           this.CURRENCY = CURRENCY;
           this.PLAN_AMT = PLAN_AMT;
           this.CUST_CODE = CUST_CODE;
           this.GL_ACCT = GL_ACCT;
           this.USED_COST_CNTR = USED_COST_CNTR;
           this.WBS_NO = WBS_NO;
           this.PRCH_GRUP = PRCH_GRUP;
           this.MATR_GRUP = MATR_GRUP;
           this.DELV_REQT_DATE = DELV_REQT_DATE;
           this.REQT_RESN = REQT_RESN;
           this.REQT_NAME = REQT_NAME;
           this.REAL_NAME = REAL_NAME;
    }


    /**
     * Gets the PRCH_REQT_SEQ value for this DT_PRMROROW.
     * 
     * @return PRCH_REQT_SEQ
     */
    public java.lang.String getPRCH_REQT_SEQ() {
        return PRCH_REQT_SEQ;
    }


    /**
     * Sets the PRCH_REQT_SEQ value for this DT_PRMROROW.
     * 
     * @param PRCH_REQT_SEQ
     */
    public void setPRCH_REQT_SEQ(java.lang.String PRCH_REQT_SEQ) {
        this.PRCH_REQT_SEQ = PRCH_REQT_SEQ;
    }


    /**
     * Gets the ACCT_FIXD value for this DT_PRMROROW.
     * 
     * @return ACCT_FIXD
     */
    public java.lang.String getACCT_FIXD() {
        return ACCT_FIXD;
    }


    /**
     * Sets the ACCT_FIXD value for this DT_PRMROROW.
     * 
     * @param ACCT_FIXD
     */
    public void setACCT_FIXD(java.lang.String ACCT_FIXD) {
        this.ACCT_FIXD = ACCT_FIXD;
    }


    /**
     * Gets the PRCH_DOCU_ATCL value for this DT_PRMROROW.
     * 
     * @return PRCH_DOCU_ATCL
     */
    public java.lang.String getPRCH_DOCU_ATCL() {
        return PRCH_DOCU_ATCL;
    }


    /**
     * Sets the PRCH_DOCU_ATCL value for this DT_PRMROROW.
     * 
     * @param PRCH_DOCU_ATCL
     */
    public void setPRCH_DOCU_ATCL(java.lang.String PRCH_DOCU_ATCL) {
        this.PRCH_DOCU_ATCL = PRCH_DOCU_ATCL;
    }


    /**
     * Gets the REQT_SITE_CODE value for this DT_PRMROROW.
     * 
     * @return REQT_SITE_CODE
     */
    public java.lang.String getREQT_SITE_CODE() {
        return REQT_SITE_CODE;
    }


    /**
     * Sets the REQT_SITE_CODE value for this DT_PRMROROW.
     * 
     * @param REQT_SITE_CODE
     */
    public void setREQT_SITE_CODE(java.lang.String REQT_SITE_CODE) {
        this.REQT_SITE_CODE = REQT_SITE_CODE;
    }


    /**
     * Gets the REQT_DATE value for this DT_PRMROROW.
     * 
     * @return REQT_DATE
     */
    public java.lang.String getREQT_DATE() {
        return REQT_DATE;
    }


    /**
     * Sets the REQT_DATE value for this DT_PRMROROW.
     * 
     * @param REQT_DATE
     */
    public void setREQT_DATE(java.lang.String REQT_DATE) {
        this.REQT_DATE = REQT_DATE;
    }


    /**
     * Gets the MATR_CODE value for this DT_PRMROROW.
     * 
     * @return MATR_CODE
     */
    public java.lang.String getMATR_CODE() {
        return MATR_CODE;
    }


    /**
     * Sets the MATR_CODE value for this DT_PRMROROW.
     * 
     * @param MATR_CODE
     */
    public void setMATR_CODE(java.lang.String MATR_CODE) {
        this.MATR_CODE = MATR_CODE;
    }


    /**
     * Gets the PRCH_DOCU_DETL value for this DT_PRMROROW.
     * 
     * @return PRCH_DOCU_DETL
     */
    public java.lang.String getPRCH_DOCU_DETL() {
        return PRCH_DOCU_DETL;
    }


    /**
     * Sets the PRCH_DOCU_DETL value for this DT_PRMROROW.
     * 
     * @param PRCH_DOCU_DETL
     */
    public void setPRCH_DOCU_DETL(java.lang.String PRCH_DOCU_DETL) {
        this.PRCH_DOCU_DETL = PRCH_DOCU_DETL;
    }


    /**
     * Gets the QTY_UNIT value for this DT_PRMROROW.
     * 
     * @return QTY_UNIT
     */
    public java.lang.String getQTY_UNIT() {
        return QTY_UNIT;
    }


    /**
     * Sets the QTY_UNIT value for this DT_PRMROROW.
     * 
     * @param QTY_UNIT
     */
    public void setQTY_UNIT(java.lang.String QTY_UNIT) {
        this.QTY_UNIT = QTY_UNIT;
    }


    /**
     * Gets the REQT_QTY value for this DT_PRMROROW.
     * 
     * @return REQT_QTY
     */
    public java.lang.String getREQT_QTY() {
        return REQT_QTY;
    }


    /**
     * Sets the REQT_QTY value for this DT_PRMROROW.
     * 
     * @param REQT_QTY
     */
    public void setREQT_QTY(java.lang.String REQT_QTY) {
        this.REQT_QTY = REQT_QTY;
    }


    /**
     * Gets the CURRENCY value for this DT_PRMROROW.
     * 
     * @return CURRENCY
     */
    public java.lang.String getCURRENCY() {
        return CURRENCY;
    }


    /**
     * Sets the CURRENCY value for this DT_PRMROROW.
     * 
     * @param CURRENCY
     */
    public void setCURRENCY(java.lang.String CURRENCY) {
        this.CURRENCY = CURRENCY;
    }


    /**
     * Gets the PLAN_AMT value for this DT_PRMROROW.
     * 
     * @return PLAN_AMT
     */
    public java.lang.String getPLAN_AMT() {
        return PLAN_AMT;
    }


    /**
     * Sets the PLAN_AMT value for this DT_PRMROROW.
     * 
     * @param PLAN_AMT
     */
    public void setPLAN_AMT(java.lang.String PLAN_AMT) {
        this.PLAN_AMT = PLAN_AMT;
    }


    /**
     * Gets the CUST_CODE value for this DT_PRMROROW.
     * 
     * @return CUST_CODE
     */
    public java.lang.String getCUST_CODE() {
        return CUST_CODE;
    }


    /**
     * Sets the CUST_CODE value for this DT_PRMROROW.
     * 
     * @param CUST_CODE
     */
    public void setCUST_CODE(java.lang.String CUST_CODE) {
        this.CUST_CODE = CUST_CODE;
    }


    /**
     * Gets the GL_ACCT value for this DT_PRMROROW.
     * 
     * @return GL_ACCT
     */
    public java.lang.String getGL_ACCT() {
        return GL_ACCT;
    }


    /**
     * Sets the GL_ACCT value for this DT_PRMROROW.
     * 
     * @param GL_ACCT
     */
    public void setGL_ACCT(java.lang.String GL_ACCT) {
        this.GL_ACCT = GL_ACCT;
    }


    /**
     * Gets the USED_COST_CNTR value for this DT_PRMROROW.
     * 
     * @return USED_COST_CNTR
     */
    public java.lang.String getUSED_COST_CNTR() {
        return USED_COST_CNTR;
    }


    /**
     * Sets the USED_COST_CNTR value for this DT_PRMROROW.
     * 
     * @param USED_COST_CNTR
     */
    public void setUSED_COST_CNTR(java.lang.String USED_COST_CNTR) {
        this.USED_COST_CNTR = USED_COST_CNTR;
    }


    /**
     * Gets the WBS_NO value for this DT_PRMROROW.
     * 
     * @return WBS_NO
     */
    public java.lang.String getWBS_NO() {
        return WBS_NO;
    }


    /**
     * Sets the WBS_NO value for this DT_PRMROROW.
     * 
     * @param WBS_NO
     */
    public void setWBS_NO(java.lang.String WBS_NO) {
        this.WBS_NO = WBS_NO;
    }


    /**
     * Gets the PRCH_GRUP value for this DT_PRMROROW.
     * 
     * @return PRCH_GRUP
     */
    public java.lang.String getPRCH_GRUP() {
        return PRCH_GRUP;
    }


    /**
     * Sets the PRCH_GRUP value for this DT_PRMROROW.
     * 
     * @param PRCH_GRUP
     */
    public void setPRCH_GRUP(java.lang.String PRCH_GRUP) {
        this.PRCH_GRUP = PRCH_GRUP;
    }


    /**
     * Gets the MATR_GRUP value for this DT_PRMROROW.
     * 
     * @return MATR_GRUP
     */
    public java.lang.String getMATR_GRUP() {
        return MATR_GRUP;
    }


    /**
     * Sets the MATR_GRUP value for this DT_PRMROROW.
     * 
     * @param MATR_GRUP
     */
    public void setMATR_GRUP(java.lang.String MATR_GRUP) {
        this.MATR_GRUP = MATR_GRUP;
    }


    /**
     * Gets the DELV_REQT_DATE value for this DT_PRMROROW.
     * 
     * @return DELV_REQT_DATE
     */
    public java.lang.String getDELV_REQT_DATE() {
        return DELV_REQT_DATE;
    }


    /**
     * Sets the DELV_REQT_DATE value for this DT_PRMROROW.
     * 
     * @param DELV_REQT_DATE
     */
    public void setDELV_REQT_DATE(java.lang.String DELV_REQT_DATE) {
        this.DELV_REQT_DATE = DELV_REQT_DATE;
    }


    /**
     * Gets the REQT_RESN value for this DT_PRMROROW.
     * 
     * @return REQT_RESN
     */
    public java.lang.String getREQT_RESN() {
        return REQT_RESN;
    }


    /**
     * Sets the REQT_RESN value for this DT_PRMROROW.
     * 
     * @param REQT_RESN
     */
    public void setREQT_RESN(java.lang.String REQT_RESN) {
        this.REQT_RESN = REQT_RESN;
    }


    /**
     * Gets the REQT_NAME value for this DT_PRMROROW.
     * 
     * @return REQT_NAME
     */
    public java.lang.String getREQT_NAME() {
        return REQT_NAME;
    }


    /**
     * Sets the REQT_NAME value for this DT_PRMROROW.
     * 
     * @param REQT_NAME
     */
    public void setREQT_NAME(java.lang.String REQT_NAME) {
        this.REQT_NAME = REQT_NAME;
    }


    /**
     * Gets the REAL_NAME value for this DT_PRMROROW.
     * 
     * @return REAL_NAME
     */
    public java.lang.String getREAL_NAME() {
        return REAL_NAME;
    }


    /**
     * Sets the REAL_NAME value for this DT_PRMROROW.
     * 
     * @param REAL_NAME
     */
    public void setREAL_NAME(java.lang.String REAL_NAME) {
        this.REAL_NAME = REAL_NAME;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DT_PRMROROW)) return false;
        DT_PRMROROW other = (DT_PRMROROW) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PRCH_REQT_SEQ==null && other.getPRCH_REQT_SEQ()==null) || 
             (this.PRCH_REQT_SEQ!=null &&
              this.PRCH_REQT_SEQ.equals(other.getPRCH_REQT_SEQ()))) &&
            ((this.ACCT_FIXD==null && other.getACCT_FIXD()==null) || 
             (this.ACCT_FIXD!=null &&
              this.ACCT_FIXD.equals(other.getACCT_FIXD()))) &&
            ((this.PRCH_DOCU_ATCL==null && other.getPRCH_DOCU_ATCL()==null) || 
             (this.PRCH_DOCU_ATCL!=null &&
              this.PRCH_DOCU_ATCL.equals(other.getPRCH_DOCU_ATCL()))) &&
            ((this.REQT_SITE_CODE==null && other.getREQT_SITE_CODE()==null) || 
             (this.REQT_SITE_CODE!=null &&
              this.REQT_SITE_CODE.equals(other.getREQT_SITE_CODE()))) &&
            ((this.REQT_DATE==null && other.getREQT_DATE()==null) || 
             (this.REQT_DATE!=null &&
              this.REQT_DATE.equals(other.getREQT_DATE()))) &&
            ((this.MATR_CODE==null && other.getMATR_CODE()==null) || 
             (this.MATR_CODE!=null &&
              this.MATR_CODE.equals(other.getMATR_CODE()))) &&
            ((this.PRCH_DOCU_DETL==null && other.getPRCH_DOCU_DETL()==null) || 
             (this.PRCH_DOCU_DETL!=null &&
              this.PRCH_DOCU_DETL.equals(other.getPRCH_DOCU_DETL()))) &&
            ((this.QTY_UNIT==null && other.getQTY_UNIT()==null) || 
             (this.QTY_UNIT!=null &&
              this.QTY_UNIT.equals(other.getQTY_UNIT()))) &&
            ((this.REQT_QTY==null && other.getREQT_QTY()==null) || 
             (this.REQT_QTY!=null &&
              this.REQT_QTY.equals(other.getREQT_QTY()))) &&
            ((this.CURRENCY==null && other.getCURRENCY()==null) || 
             (this.CURRENCY!=null &&
              this.CURRENCY.equals(other.getCURRENCY()))) &&
            ((this.PLAN_AMT==null && other.getPLAN_AMT()==null) || 
             (this.PLAN_AMT!=null &&
              this.PLAN_AMT.equals(other.getPLAN_AMT()))) &&
            ((this.CUST_CODE==null && other.getCUST_CODE()==null) || 
             (this.CUST_CODE!=null &&
              this.CUST_CODE.equals(other.getCUST_CODE()))) &&
            ((this.GL_ACCT==null && other.getGL_ACCT()==null) || 
             (this.GL_ACCT!=null &&
              this.GL_ACCT.equals(other.getGL_ACCT()))) &&
            ((this.USED_COST_CNTR==null && other.getUSED_COST_CNTR()==null) || 
             (this.USED_COST_CNTR!=null &&
              this.USED_COST_CNTR.equals(other.getUSED_COST_CNTR()))) &&
            ((this.WBS_NO==null && other.getWBS_NO()==null) || 
             (this.WBS_NO!=null &&
              this.WBS_NO.equals(other.getWBS_NO()))) &&
            ((this.PRCH_GRUP==null && other.getPRCH_GRUP()==null) || 
             (this.PRCH_GRUP!=null &&
              this.PRCH_GRUP.equals(other.getPRCH_GRUP()))) &&
            ((this.MATR_GRUP==null && other.getMATR_GRUP()==null) || 
             (this.MATR_GRUP!=null &&
              this.MATR_GRUP.equals(other.getMATR_GRUP()))) &&
            ((this.DELV_REQT_DATE==null && other.getDELV_REQT_DATE()==null) || 
             (this.DELV_REQT_DATE!=null &&
              this.DELV_REQT_DATE.equals(other.getDELV_REQT_DATE()))) &&
            ((this.REQT_RESN==null && other.getREQT_RESN()==null) || 
             (this.REQT_RESN!=null &&
              this.REQT_RESN.equals(other.getREQT_RESN()))) &&
            ((this.REQT_NAME==null && other.getREQT_NAME()==null) || 
             (this.REQT_NAME!=null &&
              this.REQT_NAME.equals(other.getREQT_NAME()))) &&
            ((this.REAL_NAME==null && other.getREAL_NAME()==null) || 
             (this.REAL_NAME!=null &&
              this.REAL_NAME.equals(other.getREAL_NAME())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPRCH_REQT_SEQ() != null) {
            _hashCode += getPRCH_REQT_SEQ().hashCode();
        }
        if (getACCT_FIXD() != null) {
            _hashCode += getACCT_FIXD().hashCode();
        }
        if (getPRCH_DOCU_ATCL() != null) {
            _hashCode += getPRCH_DOCU_ATCL().hashCode();
        }
        if (getREQT_SITE_CODE() != null) {
            _hashCode += getREQT_SITE_CODE().hashCode();
        }
        if (getREQT_DATE() != null) {
            _hashCode += getREQT_DATE().hashCode();
        }
        if (getMATR_CODE() != null) {
            _hashCode += getMATR_CODE().hashCode();
        }
        if (getPRCH_DOCU_DETL() != null) {
            _hashCode += getPRCH_DOCU_DETL().hashCode();
        }
        if (getQTY_UNIT() != null) {
            _hashCode += getQTY_UNIT().hashCode();
        }
        if (getREQT_QTY() != null) {
            _hashCode += getREQT_QTY().hashCode();
        }
        if (getCURRENCY() != null) {
            _hashCode += getCURRENCY().hashCode();
        }
        if (getPLAN_AMT() != null) {
            _hashCode += getPLAN_AMT().hashCode();
        }
        if (getCUST_CODE() != null) {
            _hashCode += getCUST_CODE().hashCode();
        }
        if (getGL_ACCT() != null) {
            _hashCode += getGL_ACCT().hashCode();
        }
        if (getUSED_COST_CNTR() != null) {
            _hashCode += getUSED_COST_CNTR().hashCode();
        }
        if (getWBS_NO() != null) {
            _hashCode += getWBS_NO().hashCode();
        }
        if (getPRCH_GRUP() != null) {
            _hashCode += getPRCH_GRUP().hashCode();
        }
        if (getMATR_GRUP() != null) {
            _hashCode += getMATR_GRUP().hashCode();
        }
        if (getDELV_REQT_DATE() != null) {
            _hashCode += getDELV_REQT_DATE().hashCode();
        }
        if (getREQT_RESN() != null) {
            _hashCode += getREQT_RESN().hashCode();
        }
        if (getREQT_NAME() != null) {
            _hashCode += getREQT_NAME().hashCode();
        }
        if (getREAL_NAME() != null) {
            _hashCode += getREAL_NAME().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DT_PRMROROW.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://Nongshim.com/pis/pu", ">DT_PRMRO>ROW"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRCH_REQT_SEQ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PRCH_REQT_SEQ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ACCT_FIXD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ACCT_FIXD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRCH_DOCU_ATCL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PRCH_DOCU_ATCL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQT_SITE_CODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQT_SITE_CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQT_DATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQT_DATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MATR_CODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MATR_CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRCH_DOCU_DETL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PRCH_DOCU_DETL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QTY_UNIT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QTY_UNIT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQT_QTY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQT_QTY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CURRENCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CURRENCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PLAN_AMT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PLAN_AMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUST_CODE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUST_CODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GL_ACCT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GL_ACCT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USED_COST_CNTR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "USED_COST_CNTR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WBS_NO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "WBS_NO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRCH_GRUP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PRCH_GRUP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MATR_GRUP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MATR_GRUP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELV_REQT_DATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DELV_REQT_DATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQT_RESN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQT_RESN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REQT_NAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REQT_NAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REAL_NAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REAL_NAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
