package com.Nongshim.servicePrReqt.model;

public class InfoReqt 
{
	private String matrCode;
	private String matrName; 
	private String matrUnit;
	private String currUnit;
	private String postNo;
	private	String ordrDate;
	private	String reqtText;	
	private String empNo;
	private String empName;
	
	public String getMatrCode() {
		return matrCode;
	}
	public void setMatrCode(String matrCode) {
		this.matrCode = matrCode;
	}
	public String getMatrName() {
		return matrName;
	}
	public void setMatrName(String matrName) {
		this.matrName = matrName;
	}
	public String getMatrUnit() {
		return matrUnit;
	}
	public void setMatrUnit(String matrUnit) {
		this.matrUnit = matrUnit;
	}
	public String getCurrUnit() {
		return currUnit;
	}
	public void setCurrUnit(String currUnit) {
		this.currUnit = currUnit;
	}
	public String getPostNo() {
		return postNo;
	}
	public void setPostNo(String postNo) {
		this.postNo = postNo;
	}
	public String getOrdrDate() {
		return ordrDate;
	}
	public void setOrdrDate(String ordrDate) {
		this.ordrDate = ordrDate;
	}
	public String getReqtText() {
		return reqtText;
	}
	public void setReqtText(String reqtText) {
		this.reqtText = reqtText;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
}
